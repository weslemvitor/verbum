// src/whatsapp-tab.js
async function whatsAppTab(tabs = chrome.tabs) {
  const [active] = await tabs.query({ active: true, currentWindow: true });
  if (active?.url?.startsWith("https://web.whatsapp.com/")) return active;
  const matches = await tabs.query({ url: "https://web.whatsapp.com/*" });
  if (matches.length === 1) return matches[0];
  if (matches.length > 1) throw new Error("H\xE1 mais de uma aba do WhatsApp. Selecione a desejada fora da tela dividida.");
  throw new Error("Abra o WhatsApp Web para usar esta a\xE7\xE3o.");
}

// src/read-all-popup.js
var button = document.querySelector("#read-all");
var confirm = document.querySelector("#read-confirm");
var cancel = document.querySelector("#read-cancel");
var preview = document.querySelector("#read-preview");
var message = document.querySelector("#read-status");
var target;
var plan;
var timer;
var generation = 0;
async function request(type, extra = {}) {
  if (!target) {
    const tab = await whatsAppTab();
    target = tab.id;
  }
  let response;
  try {
    response = await chrome.tabs.sendMessage(target, { type, ...extra });
  } catch {
    throw new Error("Recarregue o WhatsApp Web e tente novamente.");
  }
  if (!response?.ok) throw new Error(response?.error || "Aguarde o WhatsApp conectar e tente novamente.");
  return response.result;
}
function show(result) {
  clearTimeout(timer);
  const running = result.state === "running";
  button.disabled = running;
  preview.hidden = result.state !== "preview" || !result.total;
  button.hidden = !preview.hidden;
  if (result.state === "preview") {
    plan = result.id;
    message.textContent = result.total ? `Marcar ${result.total} ${result.total === 1 ? "conversa como lida" : "conversas como lidas"}? Inclui grupos e arquivadas.` : "Todas as conversas sincronizadas j\xE1 est\xE3o lidas.";
  }
  if (running) {
    message.textContent = `Marcando conversas\u2026 ${result.processed} de ${result.total}.`;
    timer = setTimeout(refresh, 750);
  }
  if (result.state === "done") {
    message.textContent = `${result.marked} ${result.marked === 1 ? "conversa marcada como lida" : "conversas marcadas como lidas"}.`;
    if (result.failed) message.textContent += ` Falha em ${result.failed} ${result.failed === 1 ? "conversa" : "conversas"}. Tente novamente para concluir.`;
    if (result.error) message.textContent += ` ${result.error}`;
  }
}
async function refresh() {
  const currentGeneration = generation;
  try {
    const result = await request("READ_CHATS_STATUS");
    if (currentGeneration === generation) show(result);
  } catch (error) {
    if (currentGeneration === generation) {
      message.textContent = error.message;
      button.disabled = false;
    }
  }
}
button.addEventListener("click", async () => {
  generation++;
  button.disabled = true;
  message.textContent = "Contando conversas n\xE3o lidas\u2026";
  try {
    show(await request("READ_CHATS_PREPARE"));
  } catch (error) {
    message.textContent = error.message;
    button.disabled = false;
  }
});
confirm.addEventListener("click", async () => {
  generation++;
  confirm.disabled = true;
  cancel.disabled = true;
  try {
    show(await request("READ_CHATS_START", { id: plan }));
  } catch (error) {
    preview.hidden = true;
    button.hidden = false;
    message.textContent = error.message;
  } finally {
    confirm.disabled = false;
    cancel.disabled = false;
  }
});
cancel.addEventListener("click", () => {
  generation++;
  clearTimeout(timer);
  plan = void 0;
  preview.hidden = true;
  button.hidden = false;
  message.textContent = "";
});
void refresh();

// src/policy.js
var MAX_AUDIO_BYTES = 20 * 1024 * 1024;
var MAX_AUDIO_SECONDS = 10 * 60;
var DEFAULT_SETTINGS = { automatic: false, quality: "precise" };

// src/transcript-quality.js
var TRANSCRIPT_PROFILE = "whisper-large-v3-turbo-auto-guard-v2";
var MODEL_ID = "onnx-community/whisper-large-v3-turbo";
var MODEL_REVISION = "360ebcde2559d60bb474678be3c1de9ef347d01a";

// src/recognition-settings.js
function modelPreset(quality2) {
  return quality2 === "light" ? { quality: "light", modelId: "Xenova/whisper-small", revision: "2d67713f236afa48a18992566e7647f6ca848e13", baseProfile: "whisper-small-q8-guard-v1", label: "Whisper Small" } : { quality: "precise", modelId: MODEL_ID, revision: MODEL_REVISION, baseProfile: TRANSCRIPT_PROFILE, label: "Whisper Turbo" };
}

// src/popup.js
var toggle = document.querySelector("#automatic");
var status = document.querySelector("#status");
var quality = document.querySelector("#quality");
var { settings } = await chrome.storage.local.get({ settings: DEFAULT_SETTINGS });
toggle.checked = settings.automatic;
quality.value = settings.quality === "light" ? "light" : "precise";
function updateModelLabel() {
  document.querySelector("#model-label").textContent = `${modelPreset(quality.value).label} \xB7 Portugu\xEAs`;
}
updateModelLabel();
async function saveSettings(patch) {
  const { settings: settings2 = DEFAULT_SETTINGS } = await chrome.storage.local.get("settings");
  await chrome.storage.local.set({ settings: { ...DEFAULT_SETTINGS, ...settings2, ...patch } });
}
quality.addEventListener("change", async () => {
  quality.disabled = true;
  try {
    await saveSettings({ quality: quality.value });
    updateModelLabel();
    status.textContent = "Qualidade alterada. Toque em Transcrever ou Refazer no \xE1udio desejado.";
  } catch (error) {
    status.textContent = error.message;
  } finally {
    quality.disabled = false;
  }
});
toggle.addEventListener("change", async () => {
  toggle.disabled = true;
  try {
    await saveSettings({ automatic: toggle.checked });
    status.textContent = toggle.checked ? "Ativo para \xE1udios recebidos a partir de agora." : "Autom\xE1tico desligado. Uma transcri\xE7\xE3o em andamento pode terminar.";
  } catch (error) {
    status.textContent = error.message;
    toggle.checked = !toggle.checked;
  } finally {
    toggle.disabled = false;
  }
});
document.querySelector("#clear").addEventListener("click", async (event) => {
  event.target.disabled = true;
  try {
    const response = await chrome.runtime.sendMessage({ type: "CLEAR_CACHE" });
    if (!response.ok) throw new Error(response.error);
    status.textContent = "Transcri\xE7\xF5es salvas removidas. O modelo permanece baixado.";
  } catch (error) {
    status.textContent = error.message;
  } finally {
    event.target.disabled = false;
  }
});
try {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const info = await chrome.tabs.sendMessage(tab.id, { type: "TAB_STATUS" });
  status.textContent = info.status;
  document.querySelector("#indicator").classList.toggle("connected", info.ready);
} catch {
  status.textContent = "Abra ou recarregue o WhatsApp Web para come\xE7ar.";
}
