(() => {
  // src/policy.js
  var MAX_AUDIO_BYTES = 20 * 1024 * 1024;
  var MAX_AUDIO_SECONDS = 10 * 60;
  function isAudio(message) {
    return ["ptt", "audio"].includes(message?.type) && !message.viewOnce;
  }

  // src/dom-messages.js
  function isDomMessageId(id) {
    return typeof id === "string" && id.length < 512 && (/^(true|false)_[^_]+_.+/.test(id) || /^[a-f0-9]{16,64}$/i.test(id));
  }
  function serializedMessageId(message) {
    return message.id?._serialized || message.id?.toString();
  }
  function findVisibleMessages(domIds, models, activeChat) {
    const fullIds = /* @__PURE__ */ new Map();
    const shortIds = /* @__PURE__ */ new Map();
    for (const message of models) {
      fullIds.set(serializedMessageId(message), message);
      if (activeChat && message.id?.remote?.toString() === activeChat) {
        shortIds.set(message.id.id, message);
      }
    }
    return domIds.filter(isDomMessageId).flatMap((domId) => {
      const message = fullIds.get(domId) || shortIds.get(domId);
      return message ? [{ domId, message }] : [];
    });
  }

  // src/bridge.js
  var CHANNEL = "voz-local-v1";
  var token;
  var initialized = false;
  var lastAccount;
  var downloads = Promise.resolve();
  function post(type, payload = {}) {
    if (token) window.postMessage({ channel: CHANNEL, direction: "from-page", token, type, ...payload }, location.origin);
  }
  function account() {
    return window.WPP?.conn.getMyUserId()?.toString() || "";
  }
  function describe(msg) {
    return {
      id: msg.id?._serialized || msg.id?.toString(),
      type: msg.type,
      timestamp: Number(msg.t),
      fromMe: Boolean(msg.id?.fromMe || msg.fromMe || msg.isSentByMe),
      isNewMsg: msg.isNewMsg === true,
      isHistory: Boolean(msg.isMdHistoryMsg),
      viewOnce: Boolean(msg.isViewOnce || msg.isViewOnceV2 || msg.isViewOnceV2Extension),
      duration: Number(msg.duration || 0)
    };
  }
  function validId(id) {
    return typeof id === "string" && id.length < 512 && /^(true|false)_[^_]+_.+/.test(id);
  }
  async function getAudio(id) {
    if (!validId(id)) throw new Error("Identificador de \xE1udio inv\xE1lido.");
    const msg = await WPP.chat.getMessageById(id);
    const info = describe(msg);
    if (!isAudio(info)) throw new Error("Esta mensagem n\xE3o \xE9 um \xE1udio dispon\xEDvel para transcri\xE7\xE3o.");
    if (info.duration > MAX_AUDIO_SECONDS || Number(msg.size) > MAX_AUDIO_BYTES) {
      throw new Error("S\xE3o aceitos \xE1udios de at\xE9 10 minutos e 20 MB.");
    }
    const currentAccount = account();
    if (!currentAccount) throw new Error("Entre no WhatsApp Web primeiro.");
    const blob = await WPP.chat.downloadMedia(id);
    if (account() !== currentAccount) throw new Error("A conta do WhatsApp mudou. Tente novamente.");
    if (!blob.size || blob.size > MAX_AUDIO_BYTES) throw new Error("\xC1udio vazio ou maior que 20 MB.");
    const data = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result.split(",")[1]);
      reader.onerror = () => reject(new Error("N\xE3o foi poss\xEDvel ler o \xE1udio."));
      reader.readAsDataURL(blob);
    });
    return { data, mime: blob.type || msg.mimetype || "audio/ogg", account: currentAccount };
  }
  async function handle(message) {
    if (!WPP?.isReady || !account()) throw new Error("WhatsApp ainda est\xE1 conectando. Aguarde e tente novamente.");
    if (message.type === "LOOKUP") {
      const messages = [];
      const activeChat = WPP.chat.getActiveChat()?.id?.toString();
      const visible = findVisibleMessages(
        (message.ids || []).slice(0, 100),
        WPP.whatsapp.MsgStore.getModelsArray(),
        activeChat
      );
      for (const { domId, message: msg } of visible) {
        if (isAudio(describe(msg))) messages.push({ ...describe(msg), domId });
      }
      return { messages, account: account() };
    }
    if (message.type === "AUDIO") return getAudio(message.id);
    throw new Error("Opera\xE7\xE3o desconhecida.");
  }
  window.addEventListener("message", (event) => {
    const msg = event.data;
    if (event.source !== window || event.origin !== location.origin || msg?.channel !== CHANNEL || msg.direction !== "to-page") return;
    if (msg.type === "HELLO" && typeof msg.token === "string") {
      token = msg.token;
      if (initialized) post("READY", { account: account() });
      return;
    }
    if (!token || msg.token !== token || !["LOOKUP", "AUDIO"].includes(msg.type)) return;
    const run = async () => {
      try {
        post("RESPONSE", { requestId: msg.requestId, result: await handle(msg) });
      } catch (error) {
        post("RESPONSE", { requestId: msg.requestId, error: error.message });
      }
    };
    if (msg.type === "AUDIO") downloads = downloads.then(run, run);
    else void run();
  });
  var readiness = setInterval(() => {
    if (!window.WPP?.isReady || !account()) return;
    if (!initialized) {
      initialized = true;
      WPP.on("chat.new_message", (msg) => {
        const metadata = describe(msg);
        if (isAudio(metadata)) post("NEW_AUDIO", { message: metadata, account: account() });
      });
    }
    const current = account();
    if (current !== lastAccount) {
      lastAccount = current;
      post("READY", { account: current });
    }
  }, 1e3);
  window.addEventListener("pagehide", () => clearInterval(readiness), { once: true });
})();
