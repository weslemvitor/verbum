// src/policy.js
var MAX_AUDIO_BYTES = 20 * 1024 * 1024;
var MAX_AUDIO_SECONDS = 10 * 60;
var DEFAULT_SETTINGS = { automatic: false, quality: "precise" };

// src/transcript-quality.js
var TRANSCRIPT_PROFILE = "whisper-large-v3-turbo-auto-guard-v2";
var MODEL_ID = "onnx-community/whisper-large-v3-turbo";
var MODEL_REVISION = "360ebcde2559d60bb474678be3c1de9ef347d01a";

// src/recognition-settings.js
function modelPreset(quality2) {
  return quality2 === "light" ? { quality: "light", modelId: "Xenova/whisper-small", revision: "2d67713f236afa48a18992566e7647f6ca848e13", baseProfile: "whisper-small-q8-guard-v1", label: "Whisper Small" } : { quality: "precise", modelId: MODEL_ID, revision: MODEL_REVISION, baseProfile: TRANSCRIPT_PROFILE, label: "Whisper Turbo" };
}

// src/popup.js
var toggle = document.querySelector("#automatic");
var status = document.querySelector("#status");
var quality = document.querySelector("#quality");
var { settings } = await chrome.storage.local.get({ settings: DEFAULT_SETTINGS });
toggle.checked = settings.automatic;
quality.value = settings.quality === "light" ? "light" : "precise";
function updateModelLabel() {
  document.querySelector("#model-label").textContent = `${modelPreset(quality.value).label} \xB7 Portugu\xEAs`;
}
updateModelLabel();
async function saveSettings(patch) {
  const { settings: settings2 = DEFAULT_SETTINGS } = await chrome.storage.local.get("settings");
  await chrome.storage.local.set({ settings: { ...DEFAULT_SETTINGS, ...settings2, ...patch } });
}
quality.addEventListener("change", async () => {
  quality.disabled = true;
  try {
    await saveSettings({ quality: quality.value });
    updateModelLabel();
    status.textContent = "Qualidade alterada. Toque em Transcrever ou Refazer no \xE1udio desejado.";
  } catch (error) {
    status.textContent = error.message;
  } finally {
    quality.disabled = false;
  }
});
toggle.addEventListener("change", async () => {
  toggle.disabled = true;
  try {
    await saveSettings({ automatic: toggle.checked });
    status.textContent = toggle.checked ? "Ativo para \xE1udios recebidos a partir de agora." : "Autom\xE1tico desligado. Uma transcri\xE7\xE3o em andamento pode terminar.";
  } catch (error) {
    status.textContent = error.message;
    toggle.checked = !toggle.checked;
  } finally {
    toggle.disabled = false;
  }
});
document.querySelector("#clear").addEventListener("click", async (event) => {
  event.target.disabled = true;
  try {
    const response = await chrome.runtime.sendMessage({ type: "CLEAR_CACHE" });
    if (!response.ok) throw new Error(response.error);
    status.textContent = "Transcri\xE7\xF5es salvas removidas. O modelo permanece baixado.";
  } catch (error) {
    status.textContent = error.message;
  } finally {
    event.target.disabled = false;
  }
});
try {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const info = await chrome.tabs.sendMessage(tab.id, { type: "TAB_STATUS" });
  status.textContent = info.status;
  document.querySelector("#indicator").classList.toggle("connected", info.ready);
} catch {
  status.textContent = "Abra ou recarregue o WhatsApp Web para come\xE7ar.";
}
