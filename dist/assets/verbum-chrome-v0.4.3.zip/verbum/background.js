// src/policy.js
var MAX_AUDIO_BYTES = 20 * 1024 * 1024;
var MAX_AUDIO_SECONDS = 10 * 60;
var DEFAULT_SETTINGS = { automatic: false, quality: "precise" };
function cacheKey(account, id) {
  if (!account || !id || account.length > 160 || id.length > 512) throw new Error("Mensagem inv\xE1lida.");
  return `transcript:${account}:${id}`;
}

// src/transcript-quality.js
var TRANSCRIPT_PROFILE = "whisper-large-v3-turbo-auto-guard-v2";
var MODEL_ID = "onnx-community/whisper-large-v3-turbo";
var MODEL_REVISION = "360ebcde2559d60bb474678be3c1de9ef347d01a";
function transcriptProblem(text, seconds) {
  const words = (text || "").toLocaleLowerCase("pt-BR").match(/[\p{L}\p{N}]+/gu) || [];
  if (!words.length) return "Nenhuma fala reconhecida. Ou\xE7a o \xE1udio e tente novamente.";
  if (Number.isFinite(seconds) && text.length > seconds * 65 + 150) {
    return "O reconhecimento gerou texto demais para este \xE1udio. Tente transcrever novamente.";
  }
  if (words.length < 40) return null;
  if (Number.isFinite(seconds) && words.length > seconds * 8 + 25) {
    return "O reconhecimento gerou texto demais para este \xE1udio. Tente transcrever novamente.";
  }
  const phrases = /* @__PURE__ */ new Map();
  for (let i = 0; i + 6 <= words.length; i++) {
    const phrase = words.slice(i, i + 6).join(" ");
    phrases.set(phrase, (phrases.get(phrase) || 0) + 1);
  }
  const repetitions = [...phrases.values()].filter((count) => count >= 5);
  if (repetitions.length && repetitions.reduce((sum, count) => sum + count, 0) > words.length * 0.45) {
    return "O reconhecimento entrou em repeti\xE7\xE3o. N\xE3o foi poss\xEDvel obter uma transcri\xE7\xE3o confi\xE1vel.";
  }
  return null;
}

// src/recognition-settings.js
function modelPreset(quality) {
  return quality === "light" ? { quality: "light", modelId: "Xenova/whisper-small", revision: "2d67713f236afa48a18992566e7647f6ca848e13", baseProfile: "whisper-small-q8-guard-v1", label: "Whisper Small" } : { quality: "precise", modelId: MODEL_ID, revision: MODEL_REVISION, baseProfile: TRANSCRIPT_PROFILE, label: "Whisper Turbo" };
}
async function recognitionSettings(settings = {}) {
  const model = modelPreset(settings.quality);
  const compatibleProfiles = model.quality === "precise" ? [model.baseProfile, "whisper-large-v3-turbo-q8-guard-v1"] : [model.baseProfile];
  return { ...model, profile: model.baseProfile, compatibleProfiles };
}

// src/background.js
var creating;
var cacheWrites = Promise.resolve();
var localPage = (sender, path) => sender.id === chrome.runtime.id && sender.url === chrome.runtime.getURL(path);
var whatsApp = (sender) => sender.id === chrome.runtime.id && sender.tab?.id !== void 0 && sender.frameId === 0 && sender.url?.startsWith("https://web.whatsapp.com/");
async function ensureOffscreen() {
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (!contexts.length && !creating) {
    creating = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["WORKERS", "BLOBS"],
      justification: "Decodificar mensagens de voz e executar Whisper localmente em um worker."
    }).finally(() => {
      creating = void 0;
    });
  }
  if (creating) await creating;
  for (let attempt = 0; attempt < 50; attempt++) {
    const response = await chrome.runtime.sendMessage({ type: "PING_OFFSCREEN", target: "offscreen" }).catch(() => void 0);
    if (response?.ready) return;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error("O motor local n\xE3o iniciou. Recarregue a extens\xE3o e tente novamente.");
}
async function notifyTab(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message);
  } catch {
  }
}
async function readCache(account, id) {
  const key = cacheKey(account, id);
  const cached = (await chrome.storage.local.get(key))[key];
  const { settings = DEFAULT_SETTINGS } = await chrome.storage.local.get("settings");
  const recognition = await recognitionSettings(settings);
  return recognition.compatibleProfiles.includes(cached?.profile) && !transcriptProblem(cached.text) ? cached : void 0;
}
async function saveCache(message) {
  const key = cacheKey(message.account, message.id);
  await chrome.storage.local.set({ [key]: { text: message.text, at: Date.now(), profile: message.profile } });
  const all = await chrome.storage.local.get(null);
  const entries = Object.entries(all).filter(([name]) => name.startsWith("transcript:"));
  entries.sort((a, b) => b[1].at - a[1].at);
  const expired = entries.slice(500).map(([name]) => name);
  if (expired.length) await chrome.storage.local.remove(expired);
}
async function handle(message, sender) {
  if (message.type === "JOB_UPDATE" && localPage(sender, "offscreen.html")) {
    const { settings = DEFAULT_SETTINGS } = await chrome.storage.local.get("settings");
    const expected = await recognitionSettings(settings);
    if (message.text && message.profile !== expected.profile) {
      await notifyTab(message.tabId, { type: "JOB_UPDATE", account: message.account, id: message.id, error: "O reconhecimento mudou. Tente novamente com as op\xE7\xF5es atuais." });
      return { ok: false };
    }
    if (message.text) {
      cacheWrites = cacheWrites.then(() => saveCache(message));
      try {
        await cacheWrites;
      } catch {
        cacheWrites = Promise.resolve();
      }
    }
    await notifyTab(message.tabId, message);
    return { ok: true };
  }
  if (message.type === "KEEPALIVE" && localPage(sender, "offscreen.html")) return { ok: true };
  if (message.type === "CACHE_GET" && whatsApp(sender)) {
    const cached = await readCache(message.account, message.id);
    return { text: cached?.text };
  }
  if (message.type === "TRANSCRIBE" && whatsApp(sender)) {
    cacheKey(message.account, message.id);
    if (typeof message.data !== "string" || message.data.length > Math.ceil(MAX_AUDIO_BYTES * 4 / 3) + 4) {
      throw new Error("\xC1udio inv\xE1lido ou maior que o limite de 20 MB.");
    }
    const cached = await readCache(message.account, message.id);
    if (cached && !message.force) return { ok: true, text: cached.text };
    const { settings = DEFAULT_SETTINGS } = await chrome.storage.local.get("settings");
    if (message.automatic && !settings.automatic) throw new Error("Transcri\xE7\xE3o autom\xE1tica desativada.");
    const recognition = await recognitionSettings(settings);
    await ensureOffscreen();
    return chrome.runtime.sendMessage({ ...message, ...recognition, type: "QUEUE_AUDIO", target: "offscreen", tabId: sender.tab.id });
  }
  if (message.type === "CLEAR_CACHE" && localPage(sender, "popup.html")) {
    await cacheWrites;
    const data = await chrome.storage.local.get(null);
    await chrome.storage.local.remove(Object.keys(data).filter((key) => key.startsWith("transcript:")));
    const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
    await Promise.all(tabs.map((tab) => notifyTab(tab.id, { type: "CACHE_CLEARED" })));
    return { ok: true };
  }
  return void 0;
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message.target === "offscreen") return;
  if (!["JOB_UPDATE", "KEEPALIVE", "CACHE_GET", "TRANSCRIBE", "CLEAR_CACHE"].includes(message.type)) return;
  void handle(message, sender).then(respond, (error) => respond({ ok: false, error: error.message }));
  return true;
});
chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== "local" || !changes.settings || changes.settings.newValue?.automatic) return;
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (contexts.length) await chrome.runtime.sendMessage({ type: "CANCEL_AUTO", target: "offscreen" }).catch(() => {
  });
});
