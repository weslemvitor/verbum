// Configure before WA-JS initializes; this prototype has no telemetry.
window.WPPConfig = {
  ...window.WPPConfig,
  disableGoogleAnalytics: true,
  googleAnalyticsId: null,
  linkPreviewApiServers: [],
};
