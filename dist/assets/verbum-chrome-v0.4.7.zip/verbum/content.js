(() => {
  // src/policy.js
  var MAX_AUDIO_BYTES = 20 * 1024 * 1024;
  var MAX_AUDIO_SECONDS = 10 * 60;
  var MAX_QUEUE = 20;
  var DEFAULT_SETTINGS = { automatic: false, quality: "precise" };
  function isAudio(message) {
    return ["ptt", "audio"].includes(message?.type) && !message.viewOnce;
  }
  var FreshAudioGate = class {
    constructor(now = Date.now()) {
      this.since = now;
      this.enabled = false;
      this.seen = /* @__PURE__ */ new Set();
    }
    configure(enabled, now = Date.now()) {
      if (Boolean(enabled) !== this.enabled) this.since = now;
      this.enabled = Boolean(enabled);
    }
    accepts(message) {
      if (!this.enabled || !isAudio(message) || message.fromMe || !message.isNewMsg || message.isHistory || !message.id || !Number.isFinite(message.timestamp) || message.timestamp * 1e3 <= this.since || this.seen.has(message.id)) return false;
      this.seen.add(message.id);
      if (this.seen.size > 2e3) this.seen.delete(this.seen.values().next().value);
      return true;
    }
  };

  // src/dom-messages.js
  function isDomMessageId(id) {
    return typeof id === "string" && id.length < 512 && (/^(true|false)_[^_]+_.+/.test(id) || /^[a-f0-9]{16,64}$/i.test(id));
  }

  // src/transcript-view.js
  function createTranscriptView(onTranscribe, onRetry) {
    const host = document.createElement("div");
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>
    :host{display:block;clear:both;max-width:100%;margin:6px 0 3px;font:13px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--primary,#e9edef);box-sizing:border-box}
    *{box-sizing:border-box}[hidden]{display:none!important}
    .card{background:var(--incoming-background,#202c33);border:1px solid #8baba52b;border-radius:9px;padding:10px 12px;box-shadow:0 1px 2px #0001}
    .heading{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:6px}
    .title{font-size:11px;color:var(--secondary,#aebac1);font-weight:600;letter-spacing:.1px}
    button{font:inherit;font-size:12px;color:var(--teal,#79cbb3);background:none;border:0;cursor:pointer;border-radius:5px;padding:3px 0;text-align:left}
    button:hover{text-decoration:underline}button:focus-visible{outline:2px solid currentColor;outline-offset:3px}button:disabled{cursor:wait;opacity:.7;text-decoration:none}
    .transcribe{display:flex;align-items:center;gap:7px;padding:2px 0}.transcribe:before{content:'\u224B';font-size:19px;line-height:1}
    .text{margin:0;overflow-wrap:anywhere;white-space:pre-wrap;user-select:text}
    .footer{display:flex;justify-content:space-between;align-items:center;gap:14px;margin-top:7px}
    .copy,.retry{font-size:11px}.retry{color:var(--secondary,#aebac1)}.copy{padding:2px 5px}
    .error{margin:0 0 8px;font-size:12px;color:var(--secondary,#aebac1)}
    .progress{height:2px;border-radius:2px;background:#76b6a22e;margin-top:8px;overflow:hidden}.progress:after{content:'';display:block;height:100%;width:30%;background:#79cbb3;animation:loading 1.5s ease-in-out infinite}
    @keyframes loading{from{transform:translateX(-100%)}to{transform:translateX(440%)}}
    @media(prefers-reduced-motion:reduce){.progress:after{animation:none;width:100%}}
  </style><div class="card"><p class="error" role="status" hidden></p><button class="transcribe">Transcrever</button><div class="progress" hidden></div><section class="result" hidden><div class="heading"><span class="title">Transcri\xE7\xE3o</span><button class="copy" aria-label="Copiar transcri\xE7\xE3o">Copiar</button></div><p class="text"></p><div class="footer"><button class="retry" aria-label="Refazer transcri\xE7\xE3o">Refazer</button></div></section></div>`;
    let state = {};
    const text = root.querySelector(".text");
    root.querySelector(".transcribe").addEventListener("click", onTranscribe);
    root.querySelector(".retry").addEventListener("click", onRetry);
    root.querySelector(".copy").addEventListener("click", async (event) => {
      try {
        await navigator.clipboard.writeText(state.text || "");
        event.target.textContent = "Copiado";
        setTimeout(() => {
          event.target.textContent = "Copiar";
        }, 1500);
      } catch {
        event.target.textContent = "Selecione o texto";
      }
    });
    return {
      host,
      update(next) {
        state = next;
        const button = root.querySelector(".transcribe");
        button.hidden = Boolean(state.text);
        button.disabled = Boolean(state.busy);
        button.textContent = state.busy ? state.status : state.error ? "Tentar novamente" : "Transcrever";
        button.setAttribute("aria-label", button.textContent);
        root.querySelector(".progress").hidden = !state.busy;
        root.querySelector(".result").hidden = !state.text;
        root.querySelector(".error").hidden = !state.error;
        root.querySelector(".error").textContent = state.error || "";
        text.textContent = state.text || "";
      }
    };
  }
  function alignWithAudio(host, row, parent) {
    const player = row.querySelector('button[aria-label*="mensagem de voz"], button[aria-label*="voice message"], [data-icon="audio-play"], [data-icon="audio-pause"], audio');
    let bubble = player;
    while (bubble?.parentElement && bubble.parentElement !== parent && row.contains(bubble.parentElement)) {
      const rect = bubble.parentElement.getBoundingClientRect();
      if (rect.width > 440 || rect.height > 180) break;
      bubble = bubble.parentElement;
    }
    const target = (bubble || parent).getBoundingClientRect();
    const container = parent.getBoundingClientRect();
    const offset = Math.max(0, target.left - container.left);
    host.style.marginLeft = `${offset}px`;
    host.style.width = `${Math.min(360, target.width || 320)}px`;
    host.style.maxWidth = `calc(100% - ${offset}px)`;
  }

  // src/content.js
  var CHANNEL = "voz-local-v1";
  var token = crypto.randomUUID();
  var requests = /* @__PURE__ */ new Map();
  var states = /* @__PURE__ */ new Map();
  var hosts = /* @__PURE__ */ new Map();
  var views = /* @__PURE__ */ new WeakMap();
  var manualQueue = [];
  var autoQueue = [];
  var gate = new FreshAudioGate();
  var account = "";
  var ready = false;
  var scanning = false;
  var timer;
  var downloading = false;
  var statusText = "Conectando ao WhatsApp\u2026";
  function rpc(type, payload = {}) {
    return new Promise((resolve, reject) => {
      const requestId = crypto.randomUUID();
      const timeout = setTimeout(() => {
        requests.delete(requestId);
        reject(new Error("O WhatsApp n\xE3o respondeu. Recarregue a p\xE1gina e tente novamente."));
      }, type === "AUDIO" ? 12e4 : 15e3);
      requests.set(requestId, { resolve, reject, timeout });
      window.postMessage({ channel: CHANNEL, direction: "to-page", token, type, requestId, ...payload }, location.origin);
    });
  }
  function setState(id, state) {
    states.set(id, state);
    render(id);
  }
  function render(id) {
    const host = hosts.get(id);
    if (host?.isConnected) views.get(host)?.(states.get(id) || {});
  }
  function attach(row, id) {
    const existing = hosts.get(id);
    if (existing?.isConnected && row.contains(existing)) return;
    if (existing) existing.remove();
    const view = createTranscriptView(() => enqueue(id, false), () => enqueue(id, false, true));
    const host = view.host;
    host.dataset.vozLocal = id;
    const parent = row.querySelector(".message-in, .message-out") || row;
    alignWithAudio(host, row, parent);
    parent.append(host);
    hosts.set(id, host);
    views.set(host, view.update);
    render(id);
  }
  function scheduleScan() {
    clearTimeout(timer);
    timer = setTimeout(scan, 180);
  }
  async function scan() {
    if (!ready || scanning) return;
    scanning = true;
    try {
      for (const [id, host] of hosts) if (!host.isConnected) hosts.delete(id);
      const rows = /* @__PURE__ */ new Map();
      for (const row of document.querySelectorAll('#main [data-id], [data-testid="conversation-panel-messages"] [data-id]')) {
        if (isDomMessageId(row.dataset.id)) rows.set(row.dataset.id, row);
      }
      const ids = [...rows.keys()];
      for (let start = 0; start < ids.length; start += 100) {
        const result = await rpc("LOOKUP", { ids: ids.slice(start, start + 100) });
        if (result.account !== account) continue;
        for (const message of result.messages) {
          const row = rows.get(message.domId || message.id);
          if (!row?.isConnected) continue;
          if (!states.has(message.id)) {
            const cached = await chrome.runtime.sendMessage({ type: "CACHE_GET", account, id: message.id });
            if (cached?.text) states.set(message.id, { text: cached.text });
          }
          attach(row, message.id);
        }
      }
    } catch (error) {
      statusText = error.message;
    } finally {
      scanning = false;
    }
  }
  function enqueue(id, automatic, force = false) {
    const previous = states.get(id);
    if (!account || previous?.busy || previous?.text && !force) return;
    if (manualQueue.length + autoQueue.length >= MAX_QUEUE) {
      setState(id, { error: "Fila cheia. Tente novamente em alguns instantes." });
      return;
    }
    setState(id, { busy: true, status: "Na fila\u2026", automatic });
    (automatic ? autoQueue : manualQueue).push({ id, automatic, account, force });
    void drain();
  }
  async function drain() {
    if (downloading) return;
    downloading = true;
    try {
      while (manualQueue.length || autoQueue.length) {
        const job = manualQueue.shift() || autoQueue.shift();
        if (job.account !== account || job.automatic && !gate.enabled) continue;
        try {
          const cached = await chrome.runtime.sendMessage({ type: "CACHE_GET", ...job });
          if (cached?.text && !job.force) {
            setState(job.id, { text: cached.text });
            continue;
          }
          setState(job.id, { busy: true, status: "Obtendo \xE1udio\u2026", automatic: job.automatic });
          const audio = await rpc("AUDIO", { id: job.id });
          if (audio.account !== account || job.account !== account) continue;
          if (job.automatic && !gate.enabled) {
            setState(job.id, {});
            continue;
          }
          const response = await chrome.runtime.sendMessage({ type: "TRANSCRIBE", ...job, ...audio });
          if (!response?.ok) throw new Error(response?.error || "N\xE3o foi poss\xEDvel iniciar a transcri\xE7\xE3o.");
          if (response.text) setState(job.id, { text: response.text });
          else if (states.get(job.id)?.status === "Obtendo \xE1udio\u2026") setState(job.id, { busy: true, status: "Na fila local\u2026", automatic: job.automatic });
        } catch (error) {
          setState(job.id, { error: error.message });
        }
      }
    } finally {
      downloading = false;
    }
  }
  window.addEventListener("message", (event) => {
    const msg = event.data;
    if (event.source !== window || event.origin !== location.origin || msg?.channel !== CHANNEL || msg.direction !== "from-page" || msg.token !== token) return;
    if (msg.type === "RESPONSE") {
      const request = requests.get(msg.requestId);
      if (!request) return;
      clearTimeout(request.timeout);
      requests.delete(msg.requestId);
      msg.error ? request.reject(new Error(msg.error)) : request.resolve(msg.result);
    }
    if (msg.type === "READY") {
      if (account !== msg.account) {
        for (const host of hosts.values()) host.remove();
        hosts.clear();
        states.clear();
        manualQueue.length = 0;
        autoQueue.length = 0;
        const enabled = gate.enabled;
        gate = new FreshAudioGate();
        gate.configure(enabled);
      }
      account = msg.account;
      ready = Boolean(account);
      statusText = ready ? "WhatsApp conectado \xB7 reconhecimento local" : "Aguardando conex\xE3o";
      scheduleScan();
    }
    if (msg.type === "NEW_AUDIO" && msg.account === account && gate.accepts(msg.message)) {
      enqueue(msg.message.id, true);
      scheduleScan();
    }
  });
  chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (["READ_CHATS_STATUS", "READ_CHATS_PREPARE", "READ_CHATS_START"].includes(msg.type)) {
      if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL("popup.html")) return;
      void rpc(msg.type, { id: msg.id }).then(
        (result) => respond({ ok: true, result }),
        (error) => respond({ ok: false, error: error.message })
      );
      return true;
    }
    if (msg.type === "TAB_STATUS") {
      respond({ ready, automatic: gate.enabled, status: statusText });
      return;
    }
    if (msg.type === "JOB_UPDATE" && msg.account === account) {
      if (msg.text) setState(msg.id, { text: msg.text });
      else if (msg.error) setState(msg.id, { error: msg.error });
      else if (msg.cancelled) setState(msg.id, {});
      else setState(msg.id, { busy: true, status: msg.status });
    }
    if (msg.type === "CACHE_CLEARED") {
      for (const [id, state] of states) if (!state.busy) {
        states.delete(id);
        render(id);
      }
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.settings) return;
    const before = changes.settings.oldValue || {};
    const after = changes.settings.newValue || {};
    if ((before.quality || "precise") !== (after.quality || "precise")) {
      for (const [id, state] of states) if (!state.busy) {
        states.delete(id);
        render(id);
      }
    }
    gate.configure(changes.settings.newValue?.automatic);
    if (!gate.enabled) {
      for (const job of autoQueue) setState(job.id, {});
      autoQueue.length = 0;
    }
  });
  void chrome.storage.local.get({ settings: DEFAULT_SETTINGS }).then(({ settings }) => {
    gate.configure(settings.automatic);
    window.postMessage({ channel: CHANNEL, direction: "to-page", token, type: "HELLO" }, location.origin);
  });
  new MutationObserver(scheduleScan).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["data-id"] });
  setInterval(scheduleScan, 3e3);
})();
