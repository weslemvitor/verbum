// src/policy.js
var MAX_AUDIO_BYTES = 20 * 1024 * 1024;
var MAX_AUDIO_SECONDS = 10 * 60;
var MAX_QUEUE = 20;
function cacheKey(account, id) {
  if (!account || !id || account.length > 160 || id.length > 512) throw new Error("Mensagem inv\xE1lida.");
  return `transcript:${account}:${id}`;
}

// src/offscreen.js
var MODEL_IDLE_MS = 35e3;
var queue = [];
var worker;
var idleTimer;
var cpuOnly = false;
var current;
var working = false;
var resolveWorker;
var rejectWorker;
function publish(job, extra) {
  for (const tabId of job.targets || [job.tabId]) {
    void chrome.runtime.sendMessage({ type: "JOB_UPDATE", tabId, account: job.account, id: job.id, ...extra }).catch(() => {
    });
  }
}
function startWorker() {
  const next = new Worker(chrome.runtime.getURL("asr-worker.js"), { type: "module" });
  next.onmessage = ({ data }) => {
    if (worker !== next) return;
    if (data.type === "PROGRESS" && current) publish(current, { status: data.status });
    if (data.type === "RESULT") resolveWorker?.({ text: data.text, profile: data.profile });
    if (data.type === "ERROR") rejectWorker?.(new Error(data.error));
    if (data.type === "RETRY_CPU") rejectWorker?.(Object.assign(new Error("GPU indispon\xEDvel."), { retryCpu: true }));
  };
  next.onerror = () => {
    if (worker !== next) return;
    rejectWorker?.(new Error("O motor local falhou. Recarregue a extens\xE3o para tentar novamente."));
  };
  worker = next;
}
function stopWorker() {
  worker?.terminate();
  worker = void 0;
}
async function decode(data) {
  const binary = atob(data);
  if (!binary.length || binary.length > MAX_AUDIO_BYTES) throw new Error("\xC1udio inv\xE1lido ou maior que 20 MB.");
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  const context = new OfflineAudioContext(1, 1, 16e3);
  let decoded;
  try {
    decoded = await context.decodeAudioData(bytes.buffer);
  } catch {
    throw new Error("N\xE3o foi poss\xEDvel decodificar o \xE1udio. Baixe-o no WhatsApp e tente novamente.");
  }
  if (decoded.duration > MAX_AUDIO_SECONDS) throw new Error("S\xE3o aceitos \xE1udios de at\xE9 10 minutos.");
  const mono = new Float32Array(decoded.length);
  for (let channel = 0; channel < decoded.numberOfChannels; channel++) {
    const samples = decoded.getChannelData(channel);
    for (let i = 0; i < samples.length; i++) mono[i] += samples[i] / decoded.numberOfChannels;
  }
  return mono;
}
async function recognize(job) {
  const samples = await decode(job.data);
  if (!worker) startWorker();
  return new Promise((resolve, reject) => {
    resolveWorker = resolve;
    rejectWorker = reject;
    worker.postMessage({ type: "TRANSCRIBE", samples, quality: job.quality, profile: job.profile, forceCpu: cpuOnly }, [samples.buffer]);
  });
}
async function drain() {
  if (working) return;
  clearTimeout(idleTimer);
  idleTimer = void 0;
  working = true;
  const heartbeat = setInterval(() => chrome.runtime.sendMessage({ type: "KEEPALIVE" }).catch(() => {
  }), 2e4);
  try {
    while (queue.length) {
      current = queue.shift();
      const job = current;
      try {
        publish(job, { status: "Preparando \xE1udio\u2026" });
        let result;
        try {
          result = await recognize(job);
        } catch (error) {
          if (!error.retryCpu || cpuOnly) throw error;
          cpuOnly = true;
          stopWorker();
          publish(job, { status: "A acelera\xE7\xE3o falhou. Continuando na CPU\u2026" });
          result = await recognize(job);
        }
        if (!result.text?.trim()) throw new Error("Nenhuma fala reconhecida neste \xE1udio.");
        publish(job, { text: result.text.trim(), profile: result.profile });
      } catch (error) {
        publish(job, { error: error.message });
      } finally {
        delete job.data;
        resolveWorker = void 0;
        rejectWorker = void 0;
        current = void 0;
      }
    }
  } finally {
    working = false;
    clearInterval(heartbeat);
    if (worker) idleTimer = setTimeout(stopWorker, MODEL_IDLE_MS);
  }
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL("background.js") || message.target !== "offscreen") return;
  if (message.type === "PING_OFFSCREEN") {
    respond({ ready: true, online: navigator.onLine });
    return;
  }
  if (message.type === "CANCEL_AUTO") {
    for (let i = queue.length - 1; i >= 0; i--) {
      if (queue[i].automatic) publish(queue.splice(i, 1)[0], { cancelled: true });
    }
    respond({ ok: true });
    return;
  }
  if (message.type !== "QUEUE_AUDIO") return;
  const key = cacheKey(message.account, message.id);
  const duplicate = [current, ...queue].find((job) => job && cacheKey(job.account, job.id) === key && job.profile === message.profile);
  if (duplicate) {
    duplicate.targets.add(message.tabId);
    respond({ ok: true });
    return;
  }
  if (queue.length >= MAX_QUEUE) {
    respond({ ok: false, error: "Fila local cheia. Tente novamente em instantes." });
    return;
  }
  message.targets = /* @__PURE__ */ new Set([message.tabId]);
  if (message.automatic) queue.push(message);
  else queue.unshift(message);
  respond({ ok: true });
  void drain();
});
